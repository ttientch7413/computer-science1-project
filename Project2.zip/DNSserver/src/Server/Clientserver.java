package Server;

import java.io.*;
import java.net.*;
import java.util.*;

public class Clientserver{
    public static void main(String[]args)
            throws UnknownHostException, IOException{
	//Change the host String to recognize the address where the server
	String host = "localhost";
	//Change the port number to match the port number opened on the server.
	int port = 5001;
	//Create new client socket and connect to the server.
	Socket cSock = new Socket(host, port);
	//Output Stream
	PrintWriter sendOut = new PrintWriter(cSock.getOutputStream(), true);
	//Input Stream
	BufferedReader readIn = new BufferedReader(
	    new InputStreamReader(cSock.getInputStream()));
	Scanner inLine = new Scanner(System.in);
	String query = "";        
	while(true){
            //Request DNS query from user
            System.out.println("Type in a domain name to query, or 'q' to quit:");
            //send DNS query to the server. Change the URL to whatever you want to
            //query (ex. google.com, microsoft.com, umn.edu)
            query = inLine.nextLine();
            if (query.equalsIgnoreCase("q") || query.equalsIgnoreCase("quit")) {
                sendOut.println("hangup");//tell the server to disconnect
                sendOut.close();
                readIn.close();
                cSock.close();
                System.exit(0);
            }
            else{
                // System.out.println(query);
                sendOut.println(query);
                //Read in the returned information
                String data = readIn.readLine();
                //close all open Objects
                //print query information.
                System.out.println("Received: '" + data + "'\n");
            }
        }
    }
}