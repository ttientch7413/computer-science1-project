package Server;

public record monitorQuit() {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void start() {
		// TODO Auto-generated method stub
		
	}

}
