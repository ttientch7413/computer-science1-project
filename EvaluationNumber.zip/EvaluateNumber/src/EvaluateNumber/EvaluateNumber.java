 package EvaluateNumber;
 import java.util.*;
 public class EvaluateNumber {
    public static void main(String[] args) {
       Scanner sc= new Scanner(System.in); //scanner to input 
       double num1;     // first num
       double num2;    //sec num
       char op;       // operator 
       double result=0;        // to store result 
       System.out.println("Valid operators +, -, *, /.");
       System.out.println("Enter 0 to exit program");
       System.out.println();
       
       while (true) { //iterate infinite times 
           System.out.print("Enter first number: ");
           num1 = sc.nextDouble(); // get num1 
           if (num1 == 0) // if user enters 0 then breaks from the loop and end the program 
              break;
           System.out.print("Enter the operator: ");
           op = sc.next().charAt(0); //get operator 
           System.out.print("Enter second number: ");
           num2 = sc.nextDouble(); // get num2
           if(op=='+'){ //if + then add 
                  result = num1 + num2;
           }
           else if(op=='-'){ // if - then subtract
                  result = num1 - num2;
           }
           else if(op=='*'){ // if * then multiply 
                   result = num1 * num2;     
           }
           else if(op=='/'){ //if / then divide 
                   result = num1 / num2;
           }
           else{
                 System.out.println("Unknown operator: " + op); // else operator is unknown 
           } 
           System.out.println("result is " + result); //print result 
           System.out.println();             
       }
       System.out.println("Thankyou for using");
    
    } 
 }