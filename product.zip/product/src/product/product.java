package product;

import java.util.Scanner;

public class product {
  public static void main(String[] args) {
    int firstN, secondN, thirdN, fourthN;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the first numeber = ");
    firstN = sc.nextInt();
    System.out.println("Enter second number = ");
    secondN = sc.nextInt();
    System.out.println("Enter the third number = ");
    thirdN = sc.nextInt();
    System.out.println("Enter the  fourth number = ");
    fourthN = sc.nextInt();
    int sum;
    sum = firstN * secondN * thirdN * fourthN;
    System.out.println("Product is :" + sum);

  }
}
