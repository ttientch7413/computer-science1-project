module DNSserver {
}