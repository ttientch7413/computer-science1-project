package Server;


import java.net.*;

class Dnsserver {
	public static void main(String[] args) throws Exception {
		//Create a socket object.
		ServerSocket sSock = null;
		int idNumber = 1;	
		try {
			// open server socket 3999.
			sSock =  new ServerSocket(3999);
		} catch (Exception e) {
			System.out.println("is not listen on port: 3999.");
			System.exit(1); // 
		}

		System.out.println("Server is listening...");
		new monitorQuit().start(); // Start a new thread.

		while (true) {
			
			new dnsQuery(sSock.accept(), idNumber).start();
			System.out.printf(">> User %d connected:\n", idNumber);
			idNumber++;
		}
	}
}

