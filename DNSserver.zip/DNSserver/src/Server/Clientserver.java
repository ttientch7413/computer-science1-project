package Server;

import java.io.*;
import java.net.*;
import java.util.*;

public class Clientserver{
    public static void main(String[]args)
            throws UnknownHostException, IOException{
	//match the host string to recognize the one from the server
	String host = "localhost";
	//match the opened port from the server
	int port = 3999;
	//Create new client socket and connect to the server.
	Socket cSock = new Socket(host, port);
	//Output 
	PrintWriter sendOut = new PrintWriter(cSock.getOutputStream(), true);
	//Input Stream
	BufferedReader readIn = new BufferedReader(
	    new InputStreamReader(cSock.getInputStream()));
	Scanner inLine = new Scanner(System.in);
	String query = "";        
	while(true){
            //Request DNS query
            System.out.println("Type in a domain name to query, or 'q' to quit:");
            //Send DNS query to the server.
            query = inLine.nextLine();
            if (query.equalsIgnoreCase("q") || query.equalsIgnoreCase("quit")) {
                sendOut.println("hangup");//server disconnected
                sendOut.close();
                readIn.close();
                cSock.close();
                System.exit(0);
            }
            else{
                sendOut.println(query);
               
                String data = readIn.readLine();
               
                System.out.println("Received: '" + data + "'\n");
            }
        }
    }
}